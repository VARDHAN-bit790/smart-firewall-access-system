import os
from resemblyzer import VoiceEncoder, preprocess_wav
import sounddevice as sd
import numpy as np
import scipy.io.wavfile
from pathlib import Path

# Set up paths
voice_dir = Path("voice_data")
enrolled_voice_path = voice_dir / "enrolled_voice.wav"
temp_voice_path = voice_dir / "temp_voice.wav"

# Create folder if not exists
voice_dir.mkdir(exist_ok=True)

encoder = VoiceEncoder()

def record_voice(path, message):
    print(message)
    fs = 16000
    duration = 5
    recording = sd.rec(int(fs * duration), samplerate=fs, channels=1)
    sd.wait()
    scipy.io.wavfile.write(path, fs, recording)

def enroll_user():
    record_voice(enrolled_voice_path, "🎤 [Enrollment] Please say something for voice registration...")
    print("✅ Voice enrolled successfully!")

def verify_user():
    record_voice(temp_voice_path, "🎤 [Verification] Speak to verify your identity...")

    enrolled = preprocess_wav(enrolled_voice_path)
    test = preprocess_wav(temp_voice_path)

    embed_enrolled = encoder.embed_utterance(enrolled)
    embed_test = encoder.embed_utterance(test)

    similarity = np.dot(embed_enrolled, embed_test)
    print(f"🧠 Voice similarity score: {similarity:.2f}")

    if similarity > 0.75:
        print("✅ Access Granted: You are verified.")
    else:
        print("❌ Access Denied: Voice mismatch.")

# ---- Main Program ----
if not enrolled_voice_path.exists():
    enroll_user()
else:
    verify_user()
