import cv2
import os

face_data_folder = "face_data"
os.makedirs(face_data_folder, exist_ok=True)

name = input("Enter your name for face registration: ")

cap = cv2.VideoCapture(0)
print("Press 's' to save your face image. Press 'q' to quit.")

while True:
    ret, frame = cap.read()
    if not ret:
        continue

    cv2.imshow("Register Face", frame)

    key = cv2.waitKey(1)
    if key == ord('s'):
        image_path = os.path.join(face_data_folder, f"{name}.jpg")
        cv2.imwrite(image_path, frame)
        print(f"[✔] Face image saved as {image_path}")
        break
    elif key == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()
