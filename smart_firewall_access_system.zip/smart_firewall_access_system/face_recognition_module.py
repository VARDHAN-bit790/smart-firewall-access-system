import face_recognition
import cv2
import os

FACE_DATA_FOLDER = "face_data"

def load_known_faces():
    known_encodings = []
    known_names = []

    for filename in os.listdir(FACE_DATA_FOLDER):
        if filename.endswith(".jpg") or filename.endswith(".png"):
            img_path = os.path.join(FACE_DATA_FOLDER, filename)
            image = face_recognition.load_image_file(img_path)
            encoding = face_recognition.face_encodings(image)

            if encoding:
                known_encodings.append(encoding[0])
                known_names.append(filename.split('.')[0])

    return known_encodings, known_names

def recognize_face():
    known_encodings, known_names = load_known_faces()
    cap = cv2.VideoCapture(0)
    recognized_name = "Unknown"

    print("[INFO] Starting camera for face recognition...")
    while True:
        ret, frame = cap.read()
        if not ret:
            break

        rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        faces_locations = face_recognition.face_locations(rgb_frame)
        faces_encodings = face_recognition.face_encodings(rgb_frame, faces_locations)

        for face_encoding, face_location in zip(faces_encodings, faces_locations):
            matches = face_recognition.compare_faces(known_encodings, face_encoding)
            name = "Unknown"

            face_distances = face_recognition.face_distance(known_encodings, face_encoding)
            if len(face_distances) > 0:
                best_match_index = face_distances.argmin()
                if matches[best_match_index]:
                    name = known_names[best_match_index]
                    recognized_name = name

            top, right, bottom, left = face_location
            cv2.rectangle(frame, (left, top), (right, bottom), (0, 255, 0), 2)
            cv2.putText(frame, name, (left, top - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.9, (0, 255, 0), 2)

        cv2.imshow("Face Recognition", frame)

        if cv2.waitKey(1) & 0xFF == ord('q') or recognized_name != "Unknown":
            break

    cap.release()
    cv2.destroyAllWindows()
    return recognized_name